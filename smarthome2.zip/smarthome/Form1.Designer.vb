﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        picPhone = New PictureBox()
        lblTitle = New Label()
        cboMonths = New ComboBox()
        lblResults = New Label()
        btnResults = New Button()
        lblAverage = New Label()
        lblSavings = New Label()
        CType(picPhone, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' picPhone
        ' 
        picPhone.Image = CType(resources.GetObject("picPhone.Image"), Image)
        picPhone.Location = New Point(1, 3)
        picPhone.Name = "picPhone"
        picPhone.Size = New Size(451, 293)
        picPhone.SizeMode = PictureBoxSizeMode.StretchImage
        picPhone.TabIndex = 0
        picPhone.TabStop = False
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Font = New Font("Arial Black", 21.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitle.Location = New Point(490, 46)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(286, 82)
        lblTitle.TabIndex = 1
        lblTitle.Text = "Smart Home " & vbCrLf & "Electric Savings " & vbCrLf
        lblTitle.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' cboMonths
        ' 
        cboMonths.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        cboMonths.FormattingEnabled = True
        cboMonths.Items.AddRange(New Object() {"January", "February ", "March ", "April ", "May ", "June ", "July ", "August ", "September ", "October ", "November ", "December"})
        cboMonths.Location = New Point(569, 175)
        cboMonths.Name = "cboMonths"
        cboMonths.Size = New Size(132, 29)
        cboMonths.TabIndex = 2
        cboMonths.Text = "Select Month:"
        ' 
        ' lblResults
        ' 
        lblResults.AutoSize = True
        lblResults.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblResults.Location = New Point(332, 326)
        lblResults.Name = "lblResults"
        lblResults.Size = New Size(280, 21)
        lblResults.TabIndex = 3
        lblResults.Text = "The electric savings for July is $0.00"
        ' 
        ' btnResults
        ' 
        btnResults.BackColor = SystemColors.Control
        btnResults.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnResults.Location = New Point(403, 375)
        btnResults.Name = "btnResults"
        btnResults.Size = New Size(153, 39)
        btnResults.TabIndex = 4
        btnResults.Text = "Display Statistics"
        btnResults.UseVisualStyleBackColor = False
        ' 
        ' lblAverage
        ' 
        lblAverage.AutoSize = True
        lblAverage.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblAverage.Location = New Point(331, 440)
        lblAverage.Name = "lblAverage"
        lblAverage.Size = New Size(290, 21)
        lblAverage.TabIndex = 5
        lblAverage.Text = "The average monthly savings: $26.15"
        ' 
        ' lblSavings
        ' 
        lblSavings.AutoSize = True
        lblSavings.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblSavings.Location = New Point(303, 498)
        lblSavings.Name = "lblSavings"
        lblSavings.Size = New Size(407, 21)
        lblSavings.TabIndex = 6
        lblSavings.Text = "December had the most significant monthly savings"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 549)
        Controls.Add(lblSavings)
        Controls.Add(lblAverage)
        Controls.Add(btnResults)
        Controls.Add(lblResults)
        Controls.Add(cboMonths)
        Controls.Add(lblTitle)
        Controls.Add(picPhone)
        Name = "Form1"
        Text = "Smart Home Application "
        CType(picPhone, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents picPhone As PictureBox
    Friend WithEvents lblTitle As Label
    Friend WithEvents cboMonths As ComboBox
    Friend WithEvents lblResults As Label
    Friend WithEvents btnResults As Button
    Friend WithEvents lblAverage As Label
    Friend WithEvents lblSavings As Label

End Class
