﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cboMonths.Focus()
        lblResults.Text = ""
        lblAverage.Text = ""
        lblSavings.Text = ""

    End Sub

    Private Sub btnResults_Click(sender As Object, e As EventArgs) Handles btnResults.Click
        If cboMonths.SelectedIndex = 0 Then
            lblResults.Text = "The electric savings for January for $38.17"
            lblAverage.Text = "The average monthly savings $26.15"
            lblSavings.Text = "December had the most significant savings"
        ElseIf cboMonths.SelectedIndex = 1 Then
            lblResults.Text = "The electric savings for February for $41.55"
            lblAverage.Text = "The average monthly savings $26.15"
            lblSavings.Text = "December had the most significant savings"
        ElseIf cboMonths.SelectedIndex = 2 Then
            lblResults.Text = "The electric savings for March for $27.02"
            lblAverage.Text = "The average monthly savings $26.15"
            lblSavings.Text = "December had the most significant savings"
        ElseIf cboMonths.SelectedIndex = 3 Then
            lblResults.Text = "The electric savings for April for $25.91"
            lblAverage.Text = "The average monthly savings $26.15"
            lblSavings.Text = "December had the most significant savings"
        ElseIf cboMonths.SelectedIndex = 4 Then
            lblResults.Text = "The electric savings for May for $3.28"
            lblAverage.Text = "The average monthly savings $26.15"
            lblSavings.Text = "December had the most significant savings"
        ElseIf cboMonths.SelectedIndex = 5 Then
            lblResults.Text = "The electric savings for June for $18.08"
            lblAverage.Text = "The average monthly savings $26.15"
            lblSavings.Text = "December had the most significant savings"
        ElseIf cboMonths.SelectedIndex = 6 Then
            lblResults.Text = "The electric savings for July for $45.66"
            lblAverage.Text = "The average monthly savings $26.15"
            lblSavings.Text = "December had the most significant savings"
        ElseIf cboMonths.SelectedIndex = 7 Then
            lblResults.Text = "The electric savings for August for $16.17"
            lblAverage.Text = "The average monthly savings $26.15"
            lblSavings.Text = "December had the most significant savings"
        ElseIf cboMonths.SelectedIndex = 8 Then
            lblResults.Text = "The electric savings for September for $3.98"
            lblAverage.Text = "The average monthly savings $26.15"
            lblSavings.Text = "December had the most significant savings"
        ElseIf cboMonths.SelectedIndex = 9 Then
            lblResults.Text = "The electric savings for October for $17.11"
            lblAverage.Text = "The average monthly savings $26.15"
            lblSavings.Text = "December had the most significant savings"
        ElseIf cboMonths.SelectedIndex = 10 Then
            lblResults.Text = "The electric savings for November for $25.78"
            lblAverage.Text = "The average monthly savings $26.15"
            lblSavings.Text = "December had the most significant savings"
        ElseIf cboMonths.SelectedIndex = 11 Then
            lblResults.Text = "The electric savings for December for $51.03"
            lblAverage.Text = "The average monthly savings $26.15"
            lblSavings.Text = "December had the most significant savings"
        End If
    End Sub
End Class
